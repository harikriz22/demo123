from django.shortcuts import render
# from django.http import HttpResponse
# Create your views here.

def homepage(request):
    return render(request,"home.html")


def profilepage(request):
    # context = {"name":"mohan"}
    return render(request,"profile.html",
                {"name":"mohan","age":23,"location":"kochi","email":"mohan@hmail.com","phone":5673423})


def allstudents(request):

    students = [
        {'name':"mohan","age":25,"address":"kochi"},
        {'name':"mavalika","age":21,"address":"kochi"},
        {'name':"alfia","age":27,"address":"kochi"},
        {'name':"joby","age":22,"address":"kochi"},
        {'name':"kumar","age":29,"address":"kochi"},
        {'name':"nandana","age":26,"address":"kochi"},
    ]

    return render(request,"allstu.html",{'stu':students})




# students = [
#         {'name':"mohan","age":23,"address":"kochi"},
#         {'name':"mavalika","age":23,"address":"kochi"},
#         {'name':"alfia","age":23,"address":"kochi"},
#         {'name':"joby","age":23,"address":"kochi"},
#         {'name':"kumar","age":23,"address":"kochi"},
#         {'name':"nandana","age":23,"address":"kochi"},
#     ]

# for i in students:
#     print(i["name"])

# # request 
# httpresponse 


# def hello():

#     return "hari"


# hello() = "hari" 