from django.urls import path 
from .views import *
urlpatterns = [
    path("home",homepage),
    path("profile",profilepage),
    path("allstu",allstudents)
]